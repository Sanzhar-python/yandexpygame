import os
import pygame
from time import sleep
import sys
import random

def ping_pong():
    p_s = 0
    b_s = 0
    global ball_speed_x

    global ball_speed_y

    global player_speed
    
    def bot_ai():
        if bot.centery < ball.y:
            bot.top += bot_speed
        
        if bot.centery > ball.y:
            bot.bottom -= bot_speed
        
        if bot.top <= 0:
            bot.top = 0
        
        if bot.bottom >= screen_bottom:
            bot.bottom = screen_bottom
    
    def animation():
        global ball_speed_x, ball_speed_y, b_s, p_s
        ball.x += ball_speed_x
        ball.y += ball_speed_y
        if ball.top <= 0 or ball.bottom >= screen_bottom:
            ball_speed_y *= -1

        if ball.left <= 0:
            ball_restart()
            score.score_bot += 1

        if ball.right >= screen_right:
            ball_restart()
            score.score_player += 1

        if ball.colliderect(player) or ball.colliderect(bot):
            ball_speed_x *= -1
    
    def player_animation():
        global player_speed
        player.y += player_speed
        if player.top <= 0:
            player.top = 0
        if player.bottom >= screen_bottom:
            player.bottom = screen_bottom
    
    def ball_restart():
        global ball_speed_x
        global ball_speed_y
        
        ball.center = (screen_right / 2, screen_bottom / 2)
        
        ball_speed_x *= random.choice((-1, 1))
        ball_speed_y *= random.choice((-1, 1))
        
        sleep(0.1)

    def color(color):
        colour = pygame.Color(color)
        return colour
    
    pygame.init()
    font_for_heading23 = pygame.font.Font(None, 30)
    
    class Score:
        def __init__(self, screen):
            self.screen = screen
            self.score_player = 0
            self.score_bot = 0
        
        def bot_score(self):
            self.score_bot += 1
        
        def player_score(self):
            self.score_player += 1
            
        def show_bot(self):
            self.bot_lab = font_for_heading23.render(f"{self.score_bot}", False, light_grey)
            self.screen.blit(self.bot_lab, (800, 50))
        
        def show_player(self):
            self.player_lab = font_for_heading23.render(f"{self.score_player}", False, light_grey)
            self.screen.blit(self.player_lab, (100, 50))
    
    # identify the FPS of the game
    
    FPS = 60
    
    screen_size = (900, 500)
    screen_top = 0
    screen_bottom = 500
    screen_left = 0
    screen_right = 900
    
    clock = pygame.time.Clock()
    
    black = 'black'
    white = 'white'
    red = 'red'
    blue = 'blue'
    green = 'green'
    bg_color = pygame.Color((100, 100, 100))
    light_grey = (200, 200, 200)
    
    pygame.display.set_caption("Ping-Pong")
    
    screen = pygame.display.set_mode(screen_size)
    
    score = Score(screen)
    
    ball = pygame.Rect(screen_right / 2 - 7, screen_bottom / 2 - 7, 14, 14)
    player = pygame.Rect(10, screen_bottom / 2 - 30, 10, 60)
    bot = pygame.Rect(screen_right - 20, screen_bottom / 2 - 30, 10, 60)
    
    ball_speed_x = 7 * random.choice((-1, 1))
    ball_speed_y = 7 * random.choice((-1, 1))
    player_speed = 0
    bot_speed = 10
    
    while b_s < 5 and p_s < 5:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            
            pressed = pygame.key.get_pressed()
            if pressed[pygame.K_ESCAPE]:
                main()
                
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    player_speed += 10
                
                if event.key == pygame.K_UP:
                    player_speed -= 10
            
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_DOWN:
                    player_speed -= 10

                if event.key == pygame.K_UP:
                    player_speed += 10
                    
        animation()
        player_animation()
        bot_ai()
        
        screen.fill(bg_color)
        pygame.draw.rect(screen, light_grey, player)
        pygame.draw.rect(screen, light_grey, bot)
        pygame.draw.ellipse(screen, light_grey, ball)
        pygame.draw.aaline(screen, light_grey, (screen_right / 2, 0), (screen_right / 2, screen_bottom))
        
        score.show_player()
        score.show_bot()
        b_s = score.score_bot
        p_s = score.score_player
        
        pygame.display.flip()
        clock.tick(FPS)
    
    if b_s > p_s:
        print(f'Победил бот со счетом {b_s} - {p_s}!')
    else:
        print(f'Вы победили противника со счетом {p_s} - {b_s}!')

    pygame.quit()
    sys.exit()

def test():
    def load_image(name, colorkey=None):
        fullname = os.path.join('data', name)
        # если файл не существует, то выходим
        if not os.path.isfile(fullname):
            print(f"Файл с изображением '{fullname}' не найден")
            sys.exit()
        image = pygame.image.load(fullname)
        return image
    
    def color(color):
        colour = pygame.Color(color)
        return colour

    running_test = True
    
    all_sprites = pygame.sprite.Group()

    stone = pygame.sprite.Sprite()
    paper = pygame.sprite.Sprite()
    scissors = pygame.sprite.Sprite()
    
    stone.image = load_image("stone.jpeg")
    stone.rect = stone.image.get_rect()
    stone.rect.x = 50
    stone.rect.y = 250
    all_sprites.add(stone)
    
    scissors.image = load_image("scissors.jpg")
    scissors.rect = scissors.image.get_rect()
    scissors.rect.x = 250
    scissors.rect.y = 250
    all_sprites.add(scissors)
    
    paper.image = load_image('paper.jpg')
    paper.rect = paper.image.get_rect()
    paper.rect.x = 450
    paper.rect.y = 250
    all_sprites.add(paper)
    
    screen = pygame.display.set_mode((600, 500))
    pygame.display.set_caption("KNB")
    
    cont = True
    
    your_choice = ''
    
    xx = False
    
    knb = ['Камень', 'Ножницы', 'Бумага']
    
    font_for_heading = pygame.font.Font(None, 30)
    font_for_question = pygame.font.Font(None, 20)
    font_for_answer = pygame.font.Font(None, 10)
    bot_dec = 0
    
    white = "white"
    black = "black"
    blue = "blue"
    green = "green"
    red = "red"
    yellow = "yellow"
    
    while running_test:
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running_test = False
                
            pressed = pygame.key.get_pressed()
            if pressed[pygame.K_ESCAPE]:
                main()
                running_test = False
                
            if event.type == pygame.MOUSEBUTTONDOWN:
                xxxx, yyyy = event.pos
                if 50 < xxxx < 150 and 250 < yyyy < 317:
                    print('Ваш выбор - Камень')
                    your_choice = "Камень"
                    xx = True
                    
                if 250 < xxxx < 350 and 250 < yyyy < 358:
                    print('Ваш выбор - Ножницы')
                    your_choice = "Ножницы"
                    xx = True
                    
                if 450 < xxxx < 550 and 250 < yyyy < 325:
                    print("Ваш выбор - Бумага")
                    your_choice = "Бумага"
                    xx = True
                    
                if xx:
                    bot_dec = random.randint(1, 3)
                    print(f"Выбор бота - {knb[bot_dec - 1]}")
                    if bot_dec == 1:
                        if your_choice == 'Камень':
                            print("Draw")
                            xx = False
                        
                        elif your_choice == 'Ножницы':
                            print("You lost")
                            xx = False
                        
                        elif your_choice == 'Бумага':
                            print('You won')
                            xx = False
                            
                    elif bot_dec == 2:
                        if your_choice == 'Камень':
                            print("You won")
                            xx = False

                        elif your_choice == 'Ножницы':
                            print("Draw")
                            xx = False

                        elif your_choice == 'Бумага':
                            print('You lost')
                            xx = False
                    
                    elif bot_dec == 3:
                        if your_choice == 'Камень':
                            print("You lost")
                            xx = False

                        elif your_choice == 'Ножницы':
                            print("You won")
                            xx = False

                        elif your_choice == 'Бумага':
                            print('Draw')
                            xx = False
        
        screen.fill(pygame.Color('grey12'))
        
        all_sprites.draw(screen)
        
        pygame.display.flip()
                
def teststarting():
    def color(color):
        colour = pygame.Color(color)
        return colour

    font_for_heading = pygame.font.Font(None, 30)
    font_for_question = pygame.font.Font(None, 20)
    font_for_answer = pygame.font.Font(None, 10)

    white = "white"
    black = "black"
    blue = "blue"
    green = "green"
    red = "red"
    yellow = "yellow"
    byebye = True
    dpcolor = (225, 225, 225)
    color1 = (100, 100, 100)
    run = True
    azax = 455
    azay = 350
    
    screen = pygame.display.set_mode((600, 400))
    
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                
            pressed = pygame.key.get_pressed()

            if pressed[pygame.K_ESCAPE]:
                main()
                run = False

        if byebye:
            screen.fill(yellow)

            lab4 = font_for_heading.render("Проверка знаний по информатике", True, color(blue))
            lab5 = font_for_question.render("1. Предмет информатики — это:", True, color(blue))
            lab6 = font_for_question.render(
                "A) язык программирования;", True, color(blue))
            lab7 = font_for_question.render(
                "B) устройство робота;", True, color(blue))
            lab8 = font_for_question.render(
                "C) способы накопления, хранения, обработки, передачи информации;", True, color(blue))
            lab9 = font_for_question.render(
                "D) информированность общества.", True, color(blue))
            #CORRcc

            lab10 = font_for_question.render(
                "2. Тройками из нулей и единиц можно закодировать … различных символов.", True, color(blue))
            lab11 = font_for_question.render("А) 6", True, color(blue))
            lab12 = font_for_question.render("В) 8", True, color(blue))
            lab13 = font_for_question.render("С) 5", True, color(blue))
            lab14 = font_for_question.render("D) 9", True, color(blue))
            #CORRbb

            lab15 = font_for_question.render(
                "3. Капитан спрашивает матроса: «Работает ли маяк?» Матрос отвечает: «То загорается, то погаснет!» Чем является маяк в этой ситуации?", True, color(blue))
            lab16 = font_for_question.render(
                "А) Получаем информации;", True, color(blue))
            lab17 = font_for_question.render(
                "В) источником информации;", True, color(blue))
            lab18 = font_for_question.render(
                "С) каналом связи;", True, color(blue))
            lab19 = font_for_question.render("D) помехой.", True, color(blue))
            #CORRbb

            lab20 = font_for_question.render(
                "4. В каком веке появились первые устройства, способные выполнять арифметические действия?", True, color(blue))
            lab21 = font_for_question.render("А) В XVI в.;", True, color(blue))
            lab22 = font_for_question.render(
                "В) В XVII в.;", True, color(blue))
            lab23 = font_for_question.render(
                "С) В XVIII в.;", True, color(blue))
            lab24 = font_for_question.render("D) В XIX в.", True, color(blue))
            #CORRbb

            lab25 = font_for_question.render(
                "5. Механическое устройство, позволяющее складывать числа, изобрел:", True, color(blue))
            lab26 = font_for_question.render(
                "А) П. Нортон;", True, color(blue))
            lab27 = font_for_question.render(
                "В) Б. Паскаль;", True, color(blue))
            lab28 = font_for_question.render(
                "С) Г. Лейбниц;", True, color(blue))
            lab29 = font_for_question.render(
                "D) Д. Нейман.", True, color(blue))
            #CORRbb

            lab30 = font_for_question.render(
                "6. Для какой системы счисления были приспособлены первые семикосточковые счеты?", True, color(blue))
            lab31 = font_for_question.render(
                "А) Для семеричной;", True, color(blue))
            lab32 = font_for_question.render(
                "В) для двоичной;", True, color(blue))
            lab33 = font_for_question.render(
                "С) для десятичной;", True, color(blue))
            lab34 = font_for_question.render(
                "D) для унарной.", True, color(blue))
            #CORRcc

            lab35 = font_for_heading.render("Проверить", True, black)

            btnn = pygame.Rect(455, 350, 115, 40)

            screen.blit(lab4, (160, 20))

            screen.blit(lab5, (40, 60))
            screen.blit(lab6, (60, 80))
            screen.blit(lab7, (60, 100))
            screen.blit(lab8, (60, 120))
            screen.blit(lab9, (60, 140))

            screen.blit(lab10, (40, 170))
            screen.blit(lab11, (60, 190))
            screen.blit(lab12, (60, 210))
            screen.blit(lab13, (60, 230))
            screen.blit(lab14, (60, 250))

            screen.blit(lab15, (40, 280))
            screen.blit(lab16, (60, 300))
            screen.blit(lab17, (60, 320))
            screen.blit(lab18, (60, 340))
            screen.blit(lab19, (60, 360))

            screen.blit(lab20, (340, 60))
            screen.blit(lab21, (360, 80))
            screen.blit(lab22, (360, 100))
            screen.blit(lab23, (360, 120))
            screen.blit(lab24, (360, 140))

            screen.blit(lab25, (340, 170))
            screen.blit(lab26, (360, 190))
            screen.blit(lab27, (360, 210))
            screen.blit(lab28, (360, 230))
            screen.blit(lab29, (360, 250))

            screen.blit(lab30, (340, 280))
            screen.blit(lab31, (360, 300))
            screen.blit(lab32, (360, 320))
            screen.blit(lab33, (360, 340))
            screen.blit(lab34, (360, 360))

            pygame.draw.rect(screen, [255, 0, 0], btnn)
            screen.blit(lab35, (460, 360))
        if event.type == pygame.MOUSEBUTTONUP:
            x, y = event.pos
            if azax <= x <= 570 and azay <= y <= 390:
                byebye = False
                screen.fill(white)
                lab1 = font_for_question.render("Ответы", True, color(blue))
                lab11 = font_for_question.render("1.C", True, color(blue))
                lab22 = font_for_question.render("2.B", True, color(blue))
                lab33 = font_for_question.render("3.B", True, color(blue))
                lab44 = font_for_question.render("4.B", True, color(blue))
                lab55 = font_for_question.render("5.B", True, color(blue))
                lab66 = font_for_question.render("6.C", True, color(blue))

                screen.blit(lab1, (40, 60))
                screen.blit(lab11, (60, 80))
                screen.blit(lab22, (60, 100))
                screen.blit(lab33, (60, 120))
                screen.blit(lab44, (60, 140))
                screen.blit(lab55, (60, 160))
                screen.blit(lab66, (60, 180))
        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_ESCAPE]:
            byebye = True

        pygame.display.update()

def main():
    pygame.init()

    white = (255, 255, 255)
    green = (0, 255, 0)
    blue = (0, 0, 127)
    red = (255, 0, 0)
    black = (0, 0, 0)
    color1 = (100, 100, 100)
    yellow = (255, 255, 0)
    
    x, y = 600, 500
    one_x = 80
    one_recttop = 350
    two_x = 450
    two_recttop = 350
    
    screen = pygame.display.set_mode((x, y))
    
    pygame.display.set_caption("Game")
    
    start_screen = True
    running1 = False
    running2 = False
    runningame1 = False
    runningame2 = False
    
    tn = True
    ais = True
    font = pygame.font.Font(None, 30)
    font_for_heading = pygame.font.Font(None, 20)
    
    lab = font.render('Game', True, green, (220, 220, 220))
    lab2 = font_for_heading.render("Ping-Pong", True, red)
    lab3 = font_for_heading.render("Камень-Ножницы-Бумага", True, red)
    lab4 = font_for_heading.render("Тест", True, red)
    
    labRectangle = lab.get_rect()
    
    labRectangle.center = (x / 2, 150)
    btntest = pygame.Rect(80, 350, 200, 50)
    btnpingpong = pygame.Rect(450, 350, 100, 50)
    bt = pygame.Rect(250, 430, 100, 50)
    
    while start_screen:
        screen.fill((220, 220, 220))
        pygame.draw.rect(screen, blue, btntest)
        pygame.draw.rect(screen, blue, btnpingpong)
        pygame.draw.rect(screen, blue, bt)
        
        screen.blit(lab, labRectangle)
        screen.blit(lab2, (470, 355))
        screen.blit(lab3, (100, 355))
        screen.blit(lab4, (270, 435))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                start_screen = True
                running1 = False
                running2 = False
                pygame.quit()
                sys.exit()
                
            if event.type == pygame.MOUSEBUTTONUP:
                xpos, ypos = event.pos
                if one_x < xpos < 280 and one_recttop < ypos < 400:
                    start_screen = False
                    test()
                    running2 = False
                    
                if two_x < xpos < 550 and two_recttop < ypos < 400:
                    start_screen = False
                    running2 = True
                    
                if 250 < xpos < 350 and 430 < ypos < 480:
                    start_screen = False
                    teststarting()
                    running2 = False
                    
            pygame.display.update()
        
        while running2:
            ping_pong()
            running2 = False

main()
